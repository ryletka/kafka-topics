echo -e "\nserver.1=server1:2888:3888" >> /opt/zookeeper/current/conf/zoo.cfg
echo -e "\nserver.2=server2:2888:3888" >> /opt/zookeeper/current/conf/zoo.cfg
echo -e "\nserver.3=server3:2888:3888" >> /opt/zookeeper/current/conf/zoo.cfg