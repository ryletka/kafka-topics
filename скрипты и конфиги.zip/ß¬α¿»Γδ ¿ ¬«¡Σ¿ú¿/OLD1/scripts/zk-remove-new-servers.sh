sed -i '/server.4/d' /opt/zookeeper/zookeeper-3.4.13/conf/zoo.cfg
sed -i '/server.5/d' /opt/zookeeper/zookeeper-3.4.13/conf/zoo.cfg
sed -i '/server.6/d' /opt/zookeeper/zookeeper-3.4.13/conf/zoo.cfg
