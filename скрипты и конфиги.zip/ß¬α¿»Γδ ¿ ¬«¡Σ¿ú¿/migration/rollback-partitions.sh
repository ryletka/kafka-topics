if [ "$#" -eq 0 ]
then
    echo "no arguments"
    exit 1
fi

/opt/kafka/current/bin/kafka-reassign-partitions.sh --zookeeper localhost:2181/cluster_name --reassignment-json-file "rollback/rollback$1" --execute